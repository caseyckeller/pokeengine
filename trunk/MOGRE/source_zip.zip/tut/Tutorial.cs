﻿using Mogre;
using Mogre.TutorialFramework;
using System;



namespace Mogre.Tutorials
{
    class Tutorial : BaseApplication
    {
        private void CreateGrid(int numcols, int numrows, float unitsize)
        {
            ManualObject grid = mSceneMgr.CreateManualObject("grid");

            grid.Begin("BaseWhiteNoLighting", RenderOperation.OperationTypes.OT_LINE_LIST);

            float width = (float)numcols * unitsize;
            float depth = (float)numrows * unitsize;
            Vector3 center = new Vector3(-width / 2.0f, 0, -depth / 2.0f);

            for (int i = 0; i < numrows; ++i)
            {
                Vector3 s, e;
                s.x = 0.0f;
                s.z = i * unitsize;
                s.y = 0.0f;

                e.x = width;
                e.z = i * unitsize;
                e.y = 0.0f;

                grid.Position(s + center);
                grid.Position(e + center);
            }
            grid.Position(new Vector3(0.0f, 0.0f, numrows * unitsize) + center);
            grid.Position(new Vector3(width, 0.0f, numrows * unitsize) + center);

            for (int i = 0; i < numcols; ++i)
            {
                Vector3 s, e;
                s.x = i * unitsize;
                s.z = depth;
                s.y = 0.0f;

                e.x = i * unitsize;
                e.z = 0.0f;
                e.y = 0.0f;

                grid.Position(s + center);
                grid.Position(e + center);
            }
            grid.Position(new Vector3(numcols * unitsize, 0.0f, 0.0f) + center);
            grid.Position(new Vector3(numcols * unitsize, 0.0f, depth) + center);
            grid.End();

            mSceneMgr.RootSceneNode.AttachObject(grid);
        }

        public static void Main()
        {
            new Tutorial().Go();
        }

        protected override void CreateScene()
        {
           CreateGrid(100, 100, 5);

            //Play background music through Windows Media Player           
            //Make sure to add a reference to c:\windows\system32\wmp.dll first before compiling!
            //also, be sure to stick the included mp3 in c:\. Trust me, you'll enjoy it :)
           WMPLib.WindowsMediaPlayer wplayer = new WMPLib.WindowsMediaPlayer();

           wplayer.URL = "c:/song.mp3";
           wplayer.controls.play();
          
        }



    }
}